import 'package:flutter/material.dart';
import 'package:travel_app_02/models/expense.dart';
import 'package:travel_app_02/controllers/cost_controller.dart';
import 'EditCostField.dart';
import 'BottomBar.dart';

class RecapCost extends StatelessWidget {
  const RecapCost({Key? key}) : super(key: key);

  Widget _buildRecapItem(String label, String placeholderValue) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$label: ',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black),
          ),
          Expanded(
            child: Text(
              placeholderValue,
              style: const TextStyle(fontSize: 18, color: Colors.black87),
            ),
          ),
        ],
      ),
    );
  }

  void _mostraConfermaEliminazione(BuildContext context, Expense spesa) {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('CONFERMA ELIMINAZIONE SPESA'),
        content: Text('Sei sicuro di voler eliminare la spesa "${spesa.titolo}"?'),
        actions: [
          TextButton(
            onPressed: () async {
              await CostController().eliminaSpesa(spesa.id);
              if (dialogContext.mounted) Navigator.pop(dialogContext);
              if (context.mounted) Navigator.pop(context, true); // torna al Riepilogo Viaggio e segnala di ricaricare
            },
            child: const Text('SÌ'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('NO'),
          ),
        ],
      ),
    );
  }

  void _mostraMenuModifica(BuildContext context, Expense spesa) {
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(title: const Text('Titolo'), onTap: () => _apriModificaCampo(context, spesa, 'titolo', 'Titolo')),
              ListTile(title: const Text('Importo'), onTap: () => _apriModificaCampo(context, spesa, 'importo', 'Importo')),
              ListTile(title: const Text('Stato'), onTap: () => _apriModificaCampo(context, spesa, 'stato', 'Stato')),
              ListTile(title: const Text('Data'), onTap: () => _apriModificaCampo(context, spesa, 'data', 'Data')),
              ListTile(title: const Text('Metodo Pagamento'), onTap: () => _apriModificaCampo(context, spesa, 'metodoPagamento', 'Metodo Pagamento')),
              ListTile(title: const Text('Categoria'), onTap: () => _apriModificaCampo(context, spesa, 'categoria', 'Categoria')),
              ListTile(title: const Text('Attività Associata'), onTap: () => _apriModificaCampo(context, spesa, 'attivitaAssociata', 'Attività Associata')),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _apriModificaCampo(BuildContext context, Expense spesa, String campo, String label) async {
    Navigator.pop(context); // chiude il menu a tendina

    final salvato = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const EditCostField(),
        settings: RouteSettings(arguments: {'spesa': spesa, 'campo': campo, 'label': label}),
      ),
    );

    // Come per l'eliminazione: torniamo al Riepilogo Viaggio, che ricarica
    // le spese fresche dal DB.
    if (salvato == true && context.mounted) {
      Navigator.pop(context, true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final spesaPassata = ModalRoute.of(context)!.settings.arguments as Expense;
    return Scaffold(
      backgroundColor: Colors.amber,
      appBar: AppBar(
        backgroundColor: Colors.amber,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black, size: 30),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: const Text(
          'RIEPILOGO',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black, fontSize: 24),
        ),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.menu, color: Colors.black, size: 30),
            onSelected: (valore) {
              if (valore == 'elimina') {
                _mostraConfermaEliminazione(context, spesaPassata);
              } else if (valore == 'modifica') {
                _mostraMenuModifica(context, spesaPassata);
              }
            },
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'modifica', child: Text('MODIFICA SPESA')),
              PopupMenuItem(value: 'elimina', child: Text('ELIMINA SPESA')),
            ],
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildRecapItem('TITOLO', spesaPassata.titolo),
              _buildRecapItem('IMPORTO', '${spesaPassata.importo.toStringAsFixed(2)} EUR'),
              _buildRecapItem('STATO', spesaPassata.stato ?? 'Non specificato'),
              _buildRecapItem('DATA', spesaPassata.data ?? 'Non specificata'),
              _buildRecapItem('METODO DI PAGAMENTO', spesaPassata.metodoPagamento ?? 'Non specificato'),
              _buildRecapItem('CATEGORIA', spesaPassata.categoria ?? 'Non Specificato'),
              _buildRecapItem('VIAGGIO ASSOCIATO', spesaPassata.viaggioAssociato ?? 'Non specificato'),
              _buildRecapItem('ATTIVITÀ ASSOCIATA', spesaPassata.attivitaAssociata ?? 'Non specificata'),
              const SizedBox(height: 10),
              const Text(
                'NOTE:',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black),
              ),
              const SizedBox(height: 5),
              Text(
                spesaPassata.descrizione?.isNotEmpty == true ? spesaPassata.descrizione! : 'Nessuna nota',
                style: const TextStyle(fontSize: 18, color: Colors.black87),
              ),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
      bottomNavigationBar: const CustomBottomNavBar(),
    );
  }
}