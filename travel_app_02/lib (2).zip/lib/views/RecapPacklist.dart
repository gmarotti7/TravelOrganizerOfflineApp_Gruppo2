import 'package:flutter/material.dart';
import 'package:travel_app_02/controllers/pack_controller.dart';
import 'BottomBar.dart';

class RecapPacklist extends StatefulWidget {
  const RecapPacklist({super.key});

  @override
  State<RecapPacklist> createState() => _RecapPacklistState();
}

class _RecapPacklistState extends State<RecapPacklist> {
  final PackController _controller = PackController();
  List<Map<String, dynamic>> _elementi = [];
  bool _caricamento = true;
  late int _idPacklist;
  late String _titolo;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_caricamento) {
      final args = ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
      _idPacklist = args['id'] as int;
      _titolo = args['titolo'] as String;
      _caricaElementi();
    }
  }

  Future<void> _caricaElementi() async {
    final elementi = await _controller.caricaElementi(_idPacklist);
    setState(() {
      _elementi = elementi;
      _caricamento = false;
    });
  }

  void _mostraRinominaPacklist() {
    final controller = TextEditingController(text: _titolo);
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('MODIFICA TITOLO PACKLIST'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(border: OutlineInputBorder()),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              final nuovoTitolo = controller.text.trim();
              if (nuovoTitolo.isEmpty) return;
              await _controller.aggiornaTitolo(_idPacklist, nuovoTitolo);
              if (dialogContext.mounted) Navigator.pop(dialogContext);
              setState(() => _titolo = nuovoTitolo);
            },
            child: const Text('SALVA'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('ANNULLA'),
          ),
        ],
      ),
    );
  }

  void _mostraConfermaEliminazione() {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('CONFERMA ELIMINAZIONE PACKLIST'),
        content: const Text('Sei sicuro di voler eliminare questa packlist?'),
        actions: [
          TextButton(
            onPressed: () async {
              await _controller.eliminaPacklist(_idPacklist);
              if (dialogContext.mounted) Navigator.pop(dialogContext);
              if (context.mounted) Navigator.pop(context, true);
            },
            child: const Text('SÌ'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('NO'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.amber,
      appBar: AppBar(
        backgroundColor: Colors.amber,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black, size: 30),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: const Text(
          'RIEPILOGO PACKLIST',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black, fontSize: 20),
        ),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.menu, color: Colors.black, size: 30),
            onSelected: (valore) {
              if (valore == 'elimina') _mostraConfermaEliminazione();
              if (valore == 'modifica') _mostraRinominaPacklist();
            },
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'modifica', child: Text('MODIFICA PACKLIST')),
              PopupMenuItem(value: 'elimina', child: Text('ELIMINA PACKLIST')),
            ],
          ),
        ],
      ),
      body: _caricamento
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _titolo.toUpperCase(),
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black),
                  ),
                  const SizedBox(height: 20),
                  Expanded(
                    child: _elementi.isEmpty
                        ? const Center(child: Text('Nessun elemento in questa packlist'))
                        : ListView.builder(
                            itemCount: _elementi.length,
                            itemBuilder: (context, index) {
                              final item = _elementi[index];
                              final bool imballato = (item['isImballato'] as int) == 1;
                              return Container(
                                margin: const EdgeInsets.only(bottom: 8),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(5),
                                  border: Border.all(color: Colors.black, width: 1.5),
                                ),
                                child: CheckboxListTile(
                                  title: Text(
                                    item['nomeItem'].toString().toUpperCase(),
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      decoration: imballato ? TextDecoration.lineThrough : TextDecoration.none,
                                    ),
                                  ),
                                  value: imballato,
                                  activeColor: Colors.black,
                                  checkColor: Colors.amber,
                                  controlAffinity: ListTileControlAffinity.leading,
                                  onChanged: (bool? nuovoValore) async {
                                    await _controller.aggiornaStatoElemento(item['id'] as int, nuovoValore ?? false);
                                    setState(() {
                                      item['isImballato'] = (nuovoValore ?? false) ? 1 : 0;
                                    });
                                  },
                                ),
                              );
                            },
                          ),
                  ),
                ],
              ),
            ),
      bottomNavigationBar: const CustomBottomNavBar(),
    );
  }
}